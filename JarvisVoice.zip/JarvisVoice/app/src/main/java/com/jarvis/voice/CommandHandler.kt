package com.jarvis.voice

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import java.util.Locale

object CommandHandler {

    private val aliases = listOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "यूट्यूब" to "youtube", "कैमरा" to "camera", "क्रोम" to "chrome",
        "सेटिंग्स" to "settings", "सेटिंग" to "settings", "गैलरी" to "album",
        "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook", "गूगल" to "google",
        "कैलकुलेटर" to "calculator", "मैप्स" to "maps", "मैप" to "maps",
        "फोनपे" to "phonepe", "पेटीएम" to "paytm", "टेलीग्राम" to "telegram",
        "स्पॉटिफाई" to "spotify", "फोन" to "phone", "घड़ी" to "clock"
    )
    private val openWords = setOf("open", "kholo", "khol", "खोलो", "खोल", "ओपन", "चलाओ", "start",
        "launch", "करो", "kar", "do", "दो", "the", "app", "ऐप", "एप")
    private val callWords = setOf("call", "कॉल", "फोन", "फ़ोन", "करो", "kar", "do", "को", "ko",
        "लगाओ", "laga", "phone", "दो")
    private val clickWords = setOf("click", "tap", "on", "par", "पर", "दबाओ", "dabao", "क्लिक",
        "टैप", "करो", "kar", "do", "press")

    private fun launchCtx(ctx: Context): Context = JarvisAccessibilityService.instance ?: ctx

    private fun start(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launchCtx(ctx).startActivity(i)
    }

    fun handle(ctx: Context, raw: String): String {
        val t = raw.lowercase(Locale.ROOT).trim()
        fun has(vararg w: String) = w.any { t.contains(it) }
        val acc = JarvisAccessibilityService.instance
        val needAcc = "Accessibility service on karo"

        return when {
            has("back", "peeche", "पीछे", "वापस", "wapas") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)?.let { "Peeche" } ?: needAcc

            has("recent", "रीसेंट", "रिसेंट") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)?.let { "Recent apps" } ?: needAcc

            has("notification", "नोटिफिकेशन") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)?.let { "Notifications" } ?: needAcc

            has("screenshot", "स्क्रीनशॉट") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)?.let { "Screenshot le liya" } ?: needAcc

            has("lock", "लॉक") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)?.let { "Phone lock" } ?: needAcc

            has("scroll down", "neeche", "नीचे") ->
                acc?.let { it.swipe(true); "Neeche scroll" } ?: needAcc

            has("scroll up", "upar", "ऊपर", "उपर") ->
                acc?.let { it.swipe(false); "Upar scroll" } ?: needAcc

            has("volume", "वॉल्यूम", "आवाज", "awaz", "awaaz") -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                when {
                    has("mute", "म्यूट", "band", "बंद") -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Mute" }
                    has("kam", "कम", "down", "decrease", "ghata", "घटा") -> { repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }; "Volume kam" }
                    else -> { repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }; "Volume badha diya" }
                }
            }

            has("torch", "flashlight", "टॉर्च", "फ्लैशलाइट", "flash light") -> {
                val on = !has("off", "band", "बंद", "बन्द")
                setTorch(ctx, on)
                if (on) "Torch on" else "Torch off"
            }

            has("wifi", "wi-fi", "वाईफाई", "वाई-फाई") -> { start(ctx, Intent(Settings.ACTION_WIFI_SETTINGS)); "WiFi settings" }
            has("bluetooth", "ब्लूटूथ") -> { start(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "Bluetooth settings" }
            has("alarm", "अलार्म") -> { start(ctx, Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)); "Alarm" }

            has("home", "होम") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)?.let { "Home" } ?: needAcc

            has("click", "tap", "क्लिक", "टैप", "दबाओ", "dabao") -> {
                val target = t.split(" ").filter { it !in clickWords }.joinToString(" ").trim()
                if (acc == null) needAcc
                else if (target.isNotEmpty() && acc.clickText(target)) "$target dabaya" else "$target nahi mila"
            }

            has("call", "कॉल", "फोन कर", "phone kar") -> call(ctx, t)

            has("open", "kholo", "khol", "खोल", "ओपन", "chalao", "चलाओ", "launch") -> openApp(ctx, t)

            else -> "Samajh nahi aaya"
        }
    }

    private fun setTorch(ctx: Context, on: Boolean) {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return
        cm.setTorchMode(id, on)
    }

    private fun openApp(ctx: Context, t: String): String {
        var name = t.split(" ").filter { it !in openWords }.joinToString(" ").trim()
        aliases.forEach { (hi, en) -> name = name.replace(hi, en) }
        name = name.trim()
        if (name.isEmpty()) return "Kaunsa app?"
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name)
        } ?: return "$name app nahi mila"
        val li = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "Open nahi ho paya"
        start(ctx, li)
        return "$name khol raha hoon"
    }

    private fun call(ctx: Context, t: String): String {
        val name = t.split(" ").filter { it !in callWords }.joinToString(" ").trim()
        if (name.isEmpty()) return "Kisko call karoon?"
        var number = name.filter { it.isDigit() || it == '+' }
        if (number.length < 5) {
            number = lookupContact(ctx, name) ?: return "$name contact nahi mila"
        }
        val uri = Uri.parse("tel:$number")
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        start(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        return "$name ko call laga raha hoon"
    }

    private fun lookupContact(ctx: Context, name: String): String? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        ) ?: return null
        c.use { return if (it.moveToFirst()) it.getString(0) else null }
    }
}
