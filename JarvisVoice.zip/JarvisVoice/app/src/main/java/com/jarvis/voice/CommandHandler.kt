package com.jarvis.voice

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CommandHandler {

    private val aliases = listOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "यूट्यूब" to "youtube", "कैमरा" to "camera", "क्रोम" to "chrome",
        "सेटिंग्स" to "settings", "सेटिंग" to "settings", "गैलरी" to "album",
        "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook", "गूगल" to "google",
        "कैलकुलेटर" to "calculator", "मैप्स" to "maps", "मैप" to "maps",
        "फोनपे" to "phonepe", "पेटीएम" to "paytm", "टेलीग्राम" to "telegram",
        "स्पॉटिफाई" to "spotify", "फोन" to "phone", "घड़ी" to "clock"
    )
    private val openWords = setOf("open", "kholo", "khol", "खोलो", "खोल", "ओपन", "चलाओ", "chalao", "start",
        "launch", "करो", "kar", "do", "दो", "the", "app", "ऐप", "एप")
    private val callWords = setOf("call", "कॉल", "काल", "फोन", "फ़ोन", "करो", "kar", "do", "को", "ko",
        "लगाओ", "laga", "phone", "दो", "video", "वीडियो")
    private val clickWords = setOf("click", "tap", "on", "par", "पर", "दबाओ", "dabao", "क्लिक",
        "टैप", "करो", "kar", "do", "press")
    private val waDrop = setOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "व्हाट्सअप", "व्हॉट्सएप", "व्हॉट्सऐप",
        "वाट्सएप", "par", "पर", "pe", "पे", "se", "से")
    private val msgCore = setOf("message", "मैसेज", "मेसेज", "msg", "massage")
    private val msgWords = msgCore + setOf("bhejo", "भेजो", "भेज", "bhej", "send", "भेजें", "kar", "करो", "do", "दो",
        "likh", "लिख", "कर", "ki", "कि", "की", "ke", "के", "ka", "का")
    private val ytDrop = setOf("youtube", "यूट्यूब", "यू", "ट्यूब", "par", "पर", "pe", "पे", "search", "सर्च",
        "chalao", "चलाओ", "play", "प्ले", "dhundo", "ढूंढो", "ढूँढो", "karo", "करो", "kar", "do", "दो",
        "lagao", "लगाओ", "video", "वीडियो", "gaana", "गाना", "ka", "का", "ki", "की", "ke", "के", "me", "mein", "में")
    private val searchDrop = setOf("search", "सर्च", "karo", "करो", "kar", "do", "दो", "google", "गूगल", "par", "पर",
        "pe", "पे", "dhundo", "ढूंढो", "ढूँढो", "ke", "के", "baare", "बारे", "mein", "में", "ka", "का", "ki", "की")
    private val numWords = mapOf(
        "ek" to 1, "एक" to 1, "teen" to 3, "तीन" to 3, "char" to 4, "चार" to 4, "paanch" to 5, "panch" to 5, "पांच" to 5,
        "chhe" to 6, "cheh" to 6, "छह" to 6, "छः" to 6, "saat" to 7, "सात" to 7, "aath" to 8, "आठ" to 8,
        "nau" to 9, "नौ" to 9, "das" to 10, "दस" to 10, "gyarah" to 11, "ग्यारह" to 11, "barah" to 12, "बारह" to 12
    )

    private fun launchCtx(ctx: Context): Context = JarvisAccessibilityService.instance ?: ctx

    private fun start(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launchCtx(ctx).startActivity(i)
    }

    fun handle(ctx: Context, raw: String): String {
        val t = raw.lowercase(Locale.ROOT).trim()
        val tokens = t.split(" ").filter { it.isNotBlank() }
        fun has(vararg w: String) = w.any { t.contains(it) }
        val acc = JarvisAccessibilityService.instance
        val needAcc = "Accessibility service on karo"
        val waWord = has("whatsapp", "व्हाट्स", "व्हॉट्स", "वाट्स", "वॉट्स")
        val hasKo = tokens.any { it == "ko" || it == "को" }
        val wantsOpen = has("open", "kholo", "khol", "खोल", "ओपन", "chalao", "चलाओ", "launch")
        val systemWords = has("wifi", "wi-fi", "वाईफाई", "वाई-फाई", "bluetooth", "ब्लूटूथ", "alarm", "अलार्म",
            "notification", "नोटिफिकेशन", "recent", "रीसेंट", "रिसेंट", "screenshot", "स्क्रीनशॉट",
            "volume", "वॉल्यूम", "torch", "टॉर्च", "flash", "फ्लैश")

        return when {
            has("youtube", "यूट्यूब") && has("search", "सर्च", "chalao", "चलाओ", "play", "प्ले", "dhundo",
                "ढूंढो", "ढूँढो", "gaana", "गाना", "video", "वीडियो", "lagao", "लगाओ") -> youtube(ctx, tokens)

            has("message", "मैसेज", "मेसेज", "msg", "massage") && hasKo -> whatsappMessage(ctx, tokens)

            waWord && has("call", "कॉल", "काल") -> whatsappCall(ctx, tokens, has("video", "वीडियो"))

            has("call uthao", "call utha", "कॉल उठा", "call receive", "call lo", "कॉल रिसीव") -> acceptCall(ctx)

            has("call kato", "call kaat", "call kaato", "कॉल काट", "कॉल कट", "call cut", "call end", "call band", "फोन काट") -> endCall(ctx)

            has("pause", "रोको", "roko", "gaana band", "गाना बंद", "music band", "म्यूजिक बंद") ->
                media(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE, "Gaana ruk gaya")

            has("next", "agla", "अगला", "agle", "अगले") -> media(ctx, KeyEvent.KEYCODE_MEDIA_NEXT, "Agla gaana")

            has("previous", "pichla", "पिछला", "pichle", "पिछले") -> media(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Pichla gaana")

            has("gaana chalao", "gana chalao", "गाना चलाओ", "music chalao", "म्यूजिक चलाओ", "music play", "gaana play",
                "song play", "गाना लगाओ", "gaana lagao", "music lagao", "resume") -> media(ctx, KeyEvent.KEYCODE_MEDIA_PLAY, "Gaana chala diya")

            has("time kya", "waqt kya", "टाइम क्या", "वक्त क्या", "समय क्या", "kitne baje", "कितने बजे") ->
                "Abhi " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) + " baje hain"

            has("battery", "बैटरी") -> {
                val bm = ctx.getSystemService(BatteryManager::class.java)
                "Battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent hai"
            }

            has("screen padho", "screen par kya", "स्क्रीन पढ़ो", "स्क्रीन पढो", "स्क्रीन पर क्या", "read screen") ->
                acc?.screenText() ?: needAcc

            has("search", "सर्च", "dhundo", "ढूंढो", "ढूँढो") -> webSearch(ctx, tokens)

            has("likho", "लिखो", "type karo", "टाइप") -> typeText(acc, tokens, needAcc)

            wantsOpen && !systemWords -> openApp(ctx, t)

            has("back", "peeche", "पीछे", "वापस", "wapas") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)?.let { "Peeche" } ?: needAcc

            has("recent", "रीसेंट", "रिसेंट") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)?.let { "Recent apps" } ?: needAcc

            has("notification", "नोटिफिकेशन") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)?.let { "Notifications" } ?: needAcc

            has("screenshot", "स्क्रीनशॉट") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)?.let { "Screenshot le liya" } ?: needAcc

            has("lock", "लॉक") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)?.let { "Phone lock" } ?: needAcc

            has("scroll down", "neeche", "नीचे") ->
                acc?.let { it.swipe(true); "Neeche scroll" } ?: needAcc

            has("scroll up", "upar", "ऊपर", "उपर") ->
                acc?.let { it.swipe(false); "Upar scroll" } ?: needAcc

            has("switch off", "switch of", "power off", "poweroff", "shutdown", "phone band", "फोन बंद", "फ़ोन बंद", "स्विच ऑफ", "स्विच ऑफ़") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)?.let { "Power menu khul gaya, Power off dabao" } ?: needAcc

            has("volume", "वॉल्यूम", "आवाज", "awaz", "awaaz") -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                when {
                    has("mute", "म्यूट", "band", "बंद") -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Mute" }
                    has("kam", "कम", "down", "decrease", "ghata", "घटा") -> { repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }; "Volume kam" }
                    else -> { repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }; "Volume badha diya" }
                }
            }

            has("torch", "flashlight", "टॉर्च", "फ्लैशलाइट", "flash light") -> {
                val on = !has("off", "band", "बंद", "बन्द")
                setTorch(ctx, on)
                if (on) "Torch on" else "Torch off"
            }

            has("wifi", "wi-fi", "वाईफाई", "वाई-फाई") -> { start(ctx, Intent(Settings.ACTION_WIFI_SETTINGS)); "WiFi settings" }
            has("bluetooth", "ब्लूटूथ") -> { start(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "Bluetooth settings" }
            has("alarm", "अलार्म") -> setAlarm(ctx, tokens)

            has("home", "होम") ->
                acc?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)?.let { "Home" } ?: needAcc

            has("click", "tap", "क्लिक", "टैप", "दबाओ", "dabao") -> {
                val target = tokens.filter { it !in clickWords }.joinToString(" ").trim()
                if (acc == null) needAcc
                else if (target.isNotEmpty() && acc.clickText(target)) "$target dabaya" else "$target nahi mila"
            }

            has("call", "कॉल", "फोन कर", "phone kar") -> call(ctx, tokens)

            else -> "Samajh nahi aaya"
        }
    }

    /* ---------- chhote helpers ---------- */

    private fun setTorch(ctx: Context, on: Boolean) {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return
        cm.setTorchMode(id, on)
    }

    private fun media(ctx: Context, key: Int, msg: String): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return msg
    }

    private fun youtube(ctx: Context, tokens: List<String>): String {
        val q = tokens.filter { it !in ytDrop }.joinToString(" ").trim()
        if (q.isEmpty()) return openApp(ctx, "youtube kholo")
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        return "YouTube par $q"
    }

    private fun webSearch(ctx: Context, tokens: List<String>): String {
        val q = tokens.filter { it !in searchDrop }.joinToString(" ").trim()
        if (q.isEmpty()) return "Kya search karoon?"
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return "Search: $q"
    }

    private fun typeText(acc: JarvisAccessibilityService?, tokens: List<String>, needAcc: String): String {
        if (acc == null) return needAcc
        val i = tokens.indexOfFirst { it == "likho" || it == "लिखो" || it == "टाइप" || it == "type" }
        val text = (if (i >= 0) tokens.drop(i + 1) else tokens).filter { it != "karo" && it != "करो" }.joinToString(" ")
        if (text.isBlank()) return "Kya likhoon?"
        return if (acc.typeText(text)) "Likh diya" else "Pehle jis jagah likhna hai wahan tap karo"
    }

    private fun setAlarm(ctx: Context, tokens: List<String>): String {
        val t = tokens.joinToString(" ")
        var num: Int? = Regex("\\d{1,2}").find(t)?.value?.toIntOrNull()
        if (num == null) num = tokens.firstNotNullOfOrNull { numWords[it] }
        if (num == null) {
            start(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS))
            return "Alarm list"
        }
        var h: Int = num
        val pm = t.contains("shaam") || t.contains("शाम") || t.contains("raat") || t.contains("रात") ||
            t.contains("pm") || t.contains("dopahar") || t.contains("दोपहर")
        if (pm && h < 12) h += 12
        if (h > 23) return "Waqt samajh nahi aaya"
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, 0)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        start(ctx, i)
        return "Alarm $h:00 baje laga diya"
    }

    private fun acceptCall(ctx: Context): String {
        if (ctx.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED)
            return "Button 1 se Phone permission do"
        return try {
            ctx.getSystemService(TelecomManager::class.java).acceptRingingCall()
            "Call utha li"
        } catch (e: Exception) { "Call nahi utha paya" }
    }

    private fun endCall(ctx: Context): String {
        if (ctx.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED)
            return "Button 1 se Phone permission do"
        return try {
            if (Build.VERSION.SDK_INT >= 28) {
                ctx.getSystemService(TelecomManager::class.java).endCall()
                "Call kaat di"
            } else "Is phone par call katna possible nahi"
        } catch (e: Exception) { "Call nahi kat paya" }
    }

    /* ---------- naam milana (Hindi/English dono) ---------- */

    private val devCons = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'च' to "ch", 'छ' to "ch", 'ज' to "j", 'झ' to "jh",
        'ट' to "t", 'ठ' to "t", 'ड' to "d", 'ढ' to "d", 'ण' to "n", 'त' to "t", 'थ' to "th", 'द' to "d",
        'ध' to "dh", 'न' to "n", 'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m", 'य' to "y",
        'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h", 'ळ' to "l",
        '\u0958' to "k", '\u0959' to "kh", '\u095A' to "g", '\u095B' to "j", '\u095C' to "d",
        '\u095D' to "d", '\u095E' to "f", '\u095F' to "y"
    )

    private fun skeleton(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase(Locale.ROOT)) {
            val m = devCons[ch]
            if (m != null) sb.append(m) else if (ch in 'a'..'z') sb.append(ch)
        }
        var t = sb.toString()
        t = t.replace("ph", "f").replace("ch", "C").replace("sh", "S").replace("kh", "k")
            .replace("gh", "g").replace("th", "t").replace("dh", "d").replace("bh", "b")
            .replace("jh", "j").replace("ck", "k").replace("c", "k").replace("q", "k")
            .replace("w", "v").replace("z", "j").replace("x", "ks")
        t = t.filter { it !in "aeiouyhAEIOUYH" }
        val out = StringBuilder()
        for (c in t) if (out.isEmpty() || out.last() != c) out.append(c)
        return out.toString().lowercase(Locale.ROOT)
    }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** items = (naam, value). Sabse milta-julta naam dhoondh kar uski value deta hai. */
    private fun fuzzyBest(items: List<Pair<String, String>>, name: String): String? {
        val sk = skeleton(name)
        if (sk.isEmpty()) return null
        var best: String? = null
        var bestScore = Int.MAX_VALUE
        for ((label, value) in items) {
            val ls = skeleton(label)
            if (ls.isEmpty()) continue
            val wordSk = label.split(" ", "-", "_").map { skeleton(it) }.filter { it.isNotEmpty() }
            val score = when {
                ls == sk || wordSk.contains(sk) -> 0
                sk.length < 2 -> Int.MAX_VALUE
                ls.contains(sk) || (ls.length >= 3 && sk.contains(ls)) -> 1
                else -> {
                    val e = lev(sk, ls)
                    if (e <= (if (ls.length >= 6) 2 else 1)) e + 1 else Int.MAX_VALUE
                }
            }
            if (score < bestScore) { bestScore = score; best = value }
        }
        return best
    }

    /* ---------- app kholna ---------- */

    private fun openApp(ctx: Context, t: String): String {
        var name = t.split(" ").filter { it !in openWords }.joinToString(" ").trim()
        aliases.forEach { (hi, en) -> name = name.replace(hi, en) }
        name = name.trim()
        if (name.isEmpty()) return "Kaunsa app?"
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val pkg = apps.firstOrNull { it.first.lowercase(Locale.ROOT).contains(name) }?.second
            ?: fuzzyBest(apps, name)
            ?: return "$name app nahi mila"
        val li = pm.getLaunchIntentForPackage(pkg) ?: return "Open nahi ho paya"
        start(ctx, li)
        return "$name khol raha hoon"
    }

    /* ---------- contacts, call, WhatsApp ---------- */

    private fun contacts(ctx: Context): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return out
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        ) ?: return out
        c.use { while (it.moveToNext()) out.add((it.getString(0) ?: "") to (it.getString(1) ?: "")) }
        return out
    }

    private fun findNumber(ctx: Context, name: String): String? {
        val list = contacts(ctx)
        val low = name.lowercase(Locale.ROOT)
        return list.firstOrNull { it.first.lowercase(Locale.ROOT).contains(low) }?.second ?: fuzzyBest(list, name)
    }

    private fun call(ctx: Context, tokens: List<String>): String {
        val name = tokens.filter { it !in callWords }.joinToString(" ").trim()
        if (name.isEmpty()) return "Kisko call karoon?"
        var number = name.filter { it.isDigit() || it == '+' }
        if (number.length < 5) {
            number = findNumber(ctx, name) ?: return "$name contact nahi mila"
        }
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        start(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
        return "$name ko call laga raha hoon"
    }

    private fun waNumber(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("00")) d = d.substring(2)
        else if (d.startsWith("0")) d = "92" + d.substring(1)
        else if (d.length == 10 && d.startsWith("3")) d = "92$d"
        return d
    }

    private fun openWhatsApp(ctx: Context, num: String, text: String?) {
        val url = "https://wa.me/" + waNumber(num) + (if (text != null) "?text=" + Uri.encode(text) else "")
        try {
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp"))
        } catch (e: Exception) {
            try { start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e2: Exception) { }
        }
    }

    private fun whatsappMessage(ctx: Context, tokens: List<String>): String {
        val idx = tokens.indexOfFirst { it == "ko" || it == "को" }
        if (idx < 0) return "Kisko message bhejna hai?"
        val name = tokens.take(idx).filter { it !in waDrop && it !in msgWords }.joinToString(" ")
        val after = tokens.drop(idx + 1)
        val m = after.indexOfFirst { it in msgCore }
        val text = (if (m > 0) after.take(m) else after.dropWhile { it in msgWords }).joinToString(" ")
        if (name.isEmpty()) return "Kisko message bhejna hai?"
        if (text.isBlank()) return "Kya message bhejun?"
        val num = findNumber(ctx, name) ?: return "$name contact nahi mila"
        openWhatsApp(ctx, num, text)
        JarvisAccessibilityService.instance?.clickWhenReady(listOf("Send", "भेजें"))
        return "$name ko message bhej raha hoon"
    }

    private fun whatsappCall(ctx: Context, tokens: List<String>, video: Boolean): String {
        val name = tokens.filter { it !in waDrop && it !in callWords }.joinToString(" ").trim()
        if (name.isEmpty()) return "Kisko WhatsApp call karoon?"
        val num = findNumber(ctx, name) ?: return "$name contact nahi mila"
        openWhatsApp(ctx, num, null)
        JarvisAccessibilityService.instance?.let { a ->
            a.clickWhenReady(listOf(if (video) "Video call" else "Voice call"), tries = 10, first = 3000L) {
                a.clickWhenReady(listOf("Call", "CALL"), tries = 5, first = 1200L)
            }
        }
        return "$name ko WhatsApp call laga raha hoon"
    }
}
