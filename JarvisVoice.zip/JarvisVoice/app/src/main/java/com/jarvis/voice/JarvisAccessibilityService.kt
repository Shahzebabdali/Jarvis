package com.jarvis.voice

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
    }

    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    /** up=true: ungli neeche se upar (content neeche scroll hota hai) */
    fun swipe(up: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val ht = dm.heightPixels.toFloat()
        val path = Path().apply {
            if (up) { moveTo(x, ht * 0.7f); lineTo(x, ht * 0.3f) }
            else { moveTo(x, ht * 0.3f); lineTo(x, ht * 0.7f) }
        }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build(),
            null, null
        )
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (node in root.findAccessibilityNodeInfosByText(text)) {
            var c: AccessibilityNodeInfo? = node
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    /** Thodi der baad (app khulne ke baad) button dhoondh kar dabata hai; na mile to dobara koshish karta hai. */
    fun clickWhenReady(names: List<String>, tries: Int = 8, gap: Long = 800L, first: Long = 2500L, onDone: (() -> Unit)? = null) {
        var attempts = 0
        val r = object : Runnable {
            override fun run() {
                attempts++
                val ok = names.any { clickText(it) }
                if (ok) onDone?.invoke()
                else if (attempts < tries) h.postDelayed(this, gap)
            }
        }
        h.postDelayed(r, first)
    }

    /** Jis box mein cursor hai usme text likhta hai. */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val old = node.text?.toString() ?: ""
        val full = if (old.isEmpty() || node.isShowingHintText) text else "$old $text"
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, full)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Screen par jo text hai wo (shuru ka hissa) wapas deta hai. */
    fun screenText(): String {
        val root = rootInActiveWindow ?: return "Screen nahi padh paya"
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 350) return
            val s = n.text?.toString() ?: n.contentDescription?.toString()
            if (!s.isNullOrBlank()) sb.append(s).append(". ")
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return if (sb.isEmpty()) "Screen par koi text nahi" else sb.toString().take(350)
    }
}
