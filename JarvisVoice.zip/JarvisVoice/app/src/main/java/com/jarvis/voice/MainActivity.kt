package com.jarvis.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "Jarvis Voice Control\n\nPehle 1 → 4 steps karo, phir bolo:\n\"Jarvis, WhatsApp kholo\""
            textSize = 18f
        })
        fun btn(label: String, action: () -> Unit) = root.addView(Button(this).apply {
            text = label
            setOnClickListener { action() }
        })

        btn("1. Permissions do (Mic, Call, Contacts)") {
            requestPermissions(arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.POST_NOTIFICATIONS
            ), 1)
        }
        btn("2. Accessibility ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("3. Display over other apps ON karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        btn("4. Jarvis START") {
            startForegroundService(Intent(this, VoiceService::class.java))
        }
        btn("Jarvis STOP") {
            stopService(Intent(this, VoiceService::class.java))
        }
        setContentView(root)
    }
}
