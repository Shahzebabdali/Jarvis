package com.jarvis.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var checkView: TextView
    private lateinit var liveView: TextView
    private lateinit var logView: TextView
    private lateinit var input: EditText
    private lateinit var wakeBtn: Button
    private val logLines = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 48)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)

        fun tv(size: Float): TextView = TextView(this).apply { textSize = size }.also { root.addView(it) }
        fun btn(label: String, action: () -> Unit): Button =
            Button(this).apply { text = label; setOnClickListener { action() } }.also { root.addView(it) }

        tv(20f).text = "Jarvis Voice Control v2"
        checkView = tv(15f)
        liveView = tv(16f)
        logView = tv(14f)

        btn("1. Permissions do (Mic, Call, Contacts)") {
            requestPermissions(arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.POST_NOTIFICATIONS
            ), 1)
        }
        btn("2. Accessibility ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("3. Display over other apps ON karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("4. Jarvis START") {
            if (!micGranted()) {
                push("❌ Pehle button 1 se Microphone allow karo")
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            } else {
                startForegroundService(Intent(this, VoiceService::class.java))
                push("START bheja")
            }
        }
        btn("Jarvis STOP") { stopService(Intent(this, VoiceService::class.java)) }
        wakeBtn = btn("") {
            VoiceService.requireWake = !VoiceService.requireWake
            updateWake()
        }

        input = EditText(this).apply { hint = "Test: command likho (jaise: whatsapp kholo)" }
        root.addView(input)
        btn("Command chalao (bina awaaz ke test)") {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) push("Test: $t → ${CommandHandler.handle(this, t)}")
        }
        setContentView(scroll)
    }

    private fun micGranted() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun yn(b: Boolean) = if (b) "✅" else "❌"

    private fun checkup() {
        checkView.text = "Mic permission: ${yn(micGranted())}\n" +
            "Accessibility ON: ${yn(JarvisAccessibilityService.instance != null)}\n" +
            "Display over apps: ${yn(Settings.canDrawOverlays(this))}\n" +
            "Speech service: ${yn(SpeechRecognizer.isRecognitionAvailable(this))}\n" +
            "Jarvis chal raha: ${yn(VoiceService.running)}"
    }

    private fun updateWake() {
        wakeBtn.text = if (VoiceService.requireWake)
            "Wake word 'Jarvis': ON (OFF karne ke liye dabao)"
        else
            "Wake word: OFF, har awaaz command banegi (ON karne ke liye dabao)"
    }

    private fun push(s: String) {
        logLines.add(0, s)
        if (logLines.size > 8) logLines.removeAt(logLines.size - 1)
        logView.text = logLines.joinToString("\n")
        checkup()
    }

    override fun onResume() {
        super.onResume()
        checkup()
        updateWake()
        VoiceService.onStatus = { live, msg ->
            runOnUiThread { if (live) liveView.text = msg else push(msg) }
        }
    }

    override fun onPause() {
        VoiceService.onStatus = null
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        checkup()
    }
}
