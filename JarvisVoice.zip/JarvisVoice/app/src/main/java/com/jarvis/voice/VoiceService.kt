package com.jarvis.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Toast
import java.util.Locale

class VoiceService : Service(), RecognitionListener {

    companion object {
        @Volatile var onStatus: ((Boolean, String) -> Unit)? = null   // (live?, message)
        @Volatile var running = false
        @Volatile var requireWake = true
    }

    private var lang = "hi-IN"
    private lateinit var recognizer: SpeechRecognizer
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun report(msg: String, live: Boolean = false) {
        Log.d("Jarvis", msg)
        onStatus?.invoke(live, msg)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val ch = NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis sun raha hai")
            .setContentText("Bolo: Jarvis, <command>")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            report("❌ Phone mein speech recognition service nahi mili. Google app update/enable karo.")
            stopSelf()
            return
        }
        tts = TextToSpeech(this) { tts?.language = Locale("hi", "IN") }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(this)
        report("✅ Jarvis start hua, bolo: Jarvis ...")
        listen()
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try { recognizer.startListening(i) } catch (e: Exception) {
            report("Listen error: ${e.message}")
            restart(1500)
        }
    }

    private fun restart(delay: Long = 400) {
        handler.postDelayed({ if (running) listen() }, delay)
    }

    override fun onPartialResults(p: Bundle?) {
        val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!t.isNullOrBlank()) report("… $t", live = true)
    }

    override fun onResults(results: Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!text.isNullOrBlank()) {
            report("Suna: $text")
            process(text)
        }
        restart()
    }

    private fun isWake(w: String): Boolean {
        val s = w.lowercase(Locale.ROOT)
        return s.contains("jarvis") || s.contains("jarvish") || s.startsWith("jarv") ||
            s.startsWith("जार") || s.startsWith("जर्व") || s.startsWith("जरव")
    }

    private fun process(raw: String) {
        val tokens = raw.trim().split(" ").filter { it.isNotBlank() }
        val idx = tokens.indexOfFirst { isWake(it) }
        val cmd: String
        if (idx >= 0) {
            cmd = tokens.drop(idx + 1).joinToString(" ")
        } else if (requireWake) {
            report("⚠️ 'Jarvis' shabd nahi pehchana")
            return
        } else {
            cmd = raw
        }
        if (cmd.isBlank()) { report("Ji boliye..."); return }
        val reply = CommandHandler.handle(this, cmd)
        report("$cmd → $reply")
        Toast.makeText(this, reply, Toast.LENGTH_SHORT).show()
        // Awaaz se jawab sirf wake word ON hone par (nahi to khud ki awaaz sunke loop ban sakta hai)
        if (requireWake) tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun errName(e: Int) = when (e) {
        1 -> "NETWORK_TIMEOUT (internet check karo)"
        2 -> "NETWORK (internet nahi)"
        3 -> "AUDIO (mic problem)"
        4 -> "SERVER"
        5 -> "CLIENT"
        8 -> "BUSY"
        9 -> "PERMISSION (mic allow karo)"
        10 -> "TOO_MANY_REQUESTS"
        11 -> "SERVER_DISCONNECTED"
        12 -> "LANGUAGE_NOT_SUPPORTED"
        13 -> "LANGUAGE_UNAVAILABLE"
        else -> "code $e"
    }

    override fun onError(error: Int) {
        // 6 = chup raha, 7 = kuch samajh nahi aaya: normal hai, report nahi karte
        if (error != 6 && error != 7) report("⚠️ Error: ${errName(error)}")
        when (error) {
            9 -> { stopSelf(); return }
            12, 13 -> { if (lang != "en-IN") { lang = "en-IN"; report("Hindi nahi mili, English (en-IN) par switch") } }
            8 -> recognizer.cancel()
        }
        restart(if (error == 6 || error == 7) 300 else 1500)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        if (::recognizer.isInitialized) recognizer.destroy()
        tts?.shutdown()
        report("Jarvis band")
        super.onDestroy()
    }

    override fun onReadyForSpeech(p: Bundle?) { report("🎤 sun raha hoon...", live = true) }
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(t: Int, p: Bundle?) {}
}
