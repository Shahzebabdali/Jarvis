package com.jarvis.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

class VoiceService : Service(), RecognitionListener {

    // true = sirf "Jarvis ..." bolne par command chalegi (recommended)
    private val requireWake = true
    private val wakeWords = listOf("jarvis", "जार्विस", "जारविस", "जार्वीस", "जर्विस", "जार्विश")

    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private val handler = Handler()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis sun raha hai")
            .setContentText("Bolo: Jarvis, <command>")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n)

        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(this)
        listen()
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try { recognizer.startListening(i) } catch (e: Exception) { restart(1500) }
    }

    private fun restart(delay: Long = 400) {
        handler.postDelayed({ listen() }, delay)
    }

    override fun onResults(results: Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!text.isNullOrBlank()) process(text)
        restart()
    }

    private fun process(raw: String) {
        var t = raw.trim()
        if (requireWake) {
            val w = wakeWords.firstOrNull { t.lowercase().contains(it) } ?: return
            t = t.lowercase().substringAfter(w).trim()
            if (t.isEmpty()) { speak("Ji boliye"); return }
        }
        val reply = CommandHandler.handle(this, t)
        Toast.makeText(this, "$t → $reply", Toast.LENGTH_SHORT).show()
        speak(reply)
    }

    private fun speak(s: String) {
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onError(error: Int) {
        if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) recognizer.cancel()
        restart(if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 300 else 1500)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recognizer.destroy()
        tts.shutdown()
        super.onDestroy()
    }

    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(t: Int, p: Bundle?) {}
}
